World of Monster Keepers: Frontier — Android project v0.2.0

This is the Android Studio project source, not an APK installer.

Visual upgrade in v0.2.0:
- New hand-painted anime fantasy town environment for Sunmeadow.
- Revised in-world placement of the keeper, NPCs, monsters, and collectibles.
- More polished character drawing, HUD, menus, and battle backdrop.
- Background art is bundled locally; gameplay does not need an internet connection.

To build manually:
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is normally app/build/outputs/apk/debug/app-debug.apk.

The app bundles the game locally and launches fullscreen without opening an external browser.
