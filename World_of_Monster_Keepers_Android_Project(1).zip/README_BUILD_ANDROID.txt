World of Monster Keepers — Android project

This is the Android Studio project source, not an APK installer.

To build:
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is normally app/build/outputs/apk/debug/app-debug.apk.

The app bundles the game locally and launches it fullscreen without opening an external browser.
