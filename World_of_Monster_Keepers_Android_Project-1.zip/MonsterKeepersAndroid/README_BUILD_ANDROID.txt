WORLD OF MONSTER KEEPERS: FRONTIER
Android application project — offline packaged game

WHAT THIS IS
This is an Android Studio project that packages the playable game inside a standalone,
full-screen Android app. Once installed, it launches from the phone's app drawer; it does
not open Chrome and gameplay does not need an internet connection.

EASIEST BUILD: GITHUB CLOUD BUILD (NO ANDROID STUDIO NEEDED)
The project includes .github/workflows/build-apk.yml. GitHub can compile the APK on its
own servers. You will need a free GitHub account and a one-time upload of this project:

1. On your phone or a computer, sign in to GitHub and create a new repository.
2. Upload the CONTENTS of this project ZIP to the repository (the .github folder must
   also be included; make sure hidden folders are not skipped).
3. Open the repository's Actions tab.
4. Select "Build Android APK" and press "Run workflow". A push to main/master also
   starts a build automatically.
5. When the run finishes successfully, open that run and download the artifact named
   "World-of-Monster-Keepers-Frontier-debug-apk".
6. Extract the downloaded artifact ZIP on your phone, tap app-debug.apk, and approve
   Android's install-from-this-source prompt if Android asks.

The cloud workflow builds a debug APK for personal testing. It is not a signed release
for public distribution. GitHub account setup and uploading the project are still required;
this project ZIP itself is not an APK.

ALTERNATIVE: ANDROID STUDIO
1. Open this folder as an existing Android Studio project.
2. Allow Android Studio to download Android Gradle Plugin, Gradle, and Android SDK 35.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is normally created at app/build/outputs/apk/debug/app-debug.apk.

GAME CONTENT
The included game is an early playable prototype with original placeholder creatures,
character creation, exploration, starshard collection, and battles. It is not a finished
commercial-quality game. Official Monster Rancher characters and assets require permission
from their rights holders before public distribution.
